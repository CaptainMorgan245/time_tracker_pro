// lib/database_helper.dart

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:time_tracker_pro/models.dart';
//import 'package:time_tracker_pro/models/project_summary.dart';

// ============================================================================
// |                  FINAL, STABLE V7 DATABASE HELPER                      |
// ============================================================================

class DatabaseHelperV2 {
  DatabaseHelperV2._privateConstructor();
  static final DatabaseHelperV2 instance = DatabaseHelperV2._privateConstructor();

  static Database? _database;
  static Completer<Database>? _dbCompleter;
  static const String _dbName = 'time_tracker_pro.db';

  // MODIFICATION: Bump version to 7 for phases support
  static const int _dbVersion = 7;

  final ValueNotifier<int> databaseNotifier = ValueNotifier(0);

  void _notifyListeners() {
    databaseNotifier.value++;
  }

  void notifyDatabaseChanged() {
    _notifyListeners();
  }

  Future<Database> get database async {
    if (_database != null && _database!.isOpen) {
      return _database!;
    }

    if (_dbCompleter != null) {
      return _dbCompleter!.future;
    }

    _dbCompleter = Completer<Database>();

    try {
      _database = await _initDatabase();
      _dbCompleter!.complete(_database);
    } catch (e) {
      _dbCompleter!.completeError(e);
      _dbCompleter = null;
    }

    return _dbCompleter!.future;
  }

  // == MODIFIED: THIS FUNCTION NOW HANDLES DESKTOP vs MOBILE PATHS ==
  Future<String> _getDatabasePath() async {
    // Check if running on a desktop platform
    if (!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      // Use a stable location like the Documents folder for desktop
      final docDir = await getApplicationDocumentsDirectory();
      final dataDir = Directory('${docDir.path}/TimeTrackerPro');

      // Create the subdirectory if it doesn't exist
      if (!await dataDir.exists()) {
        await dataDir.create(recursive: true);
      }
      return '${dataDir.path}/$_dbName';
    } else {
      // Use the default path for mobile (Android/iOS)
      final path = await getDatabasesPath();
      return '$path/$_dbName';
    }
  }
  // == END MODIFICATION ==

  Future<Database> _initDatabase() async {
    debugPrint("[DB_V2] Initializing database...");
    final dbPath = await _getDatabasePath();
    debugPrint("[DB_V2] Database path: $dbPath");

    return await openDatabase(
      dbPath,
      version: _dbVersion,
      onCreate: _onCreate,
      onUpgrade: (db, oldVersion, newVersion) async {
        debugPrint('[DB_V2] Upgrading database from version $oldVersion to $newVersion...');

        // This is your existing migration for version 2 (fixedPrice ADD)
        if (oldVersion < 2) {
          await db.execute("ALTER TABLE projects ADD COLUMN fixedPrice REAL");
          debugPrint('[DB_V2] V2 Migration: Added fixedPrice column to projects table.');
        }

        // MODIFICATION 2: Migration logic for version 3 (fixedPrice RENAME)
        // This renames the inconsistent 'fixedPrice' to the correct 'project_price'
        if (oldVersion < 3) {
          await db.execute("ALTER TABLE projects RENAME COLUMN fixedPrice TO project_price");
          debugPrint('[DB_V2] V3 Migration: Renamed column fixedPrice to project_price in projects table.');
        }

        // MODIFICATION 3: Migration logic for version 4 (add setup_completed flag)
        if (oldVersion < 4) {
          await db.execute("ALTER TABLE settings ADD COLUMN setup_completed INTEGER DEFAULT 0");
          debugPrint('[DB_V2] V4 Migration: Added setup_completed column to settings table.');
        }
        if (oldVersion < 5) {
          await db.execute("ALTER TABLE settings ADD COLUMN expense_markup_percentage REAL DEFAULT 0.0");
          debugPrint('[DB_V2] V5 Migration: Added expense_markup_percentage column to settings table.');
        }

        if (oldVersion < 6) {
          await db.execute("ALTER TABLE projects ADD COLUMN expense_markup_percentage REAL DEFAULT 15.0");
          debugPrint('[DB_V2] V6 Migration: Added expense_markup_percentage column to projects table.');
        }

        // NEW: Migration logic for version 7 (add phases support)
        if (oldVersion < 7) {
          // Create phases table
          await db.execute('''
            CREATE TABLE IF NOT EXISTS phases (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL UNIQUE
            )
          ''');
          debugPrint('[DB_V2] V7 Migration: Created phases table.');

          // Add phase_id to time_entries
          await db.execute("ALTER TABLE time_entries ADD COLUMN phase_id INTEGER REFERENCES phases(id)");
          debugPrint('[DB_V2] V7 Migration: Added phase_id column to time_entries table.');

          // Add phase_id to materials
          await db.execute("ALTER TABLE materials ADD COLUMN phase_id INTEGER REFERENCES phases(id)");
          debugPrint('[DB_V2] V7 Migration: Added phase_id column to materials table.');

          debugPrint('[DB_V2] V7 Migration: Phase support migration complete.');
        }
      },

      onDowngrade: onDatabaseDowngradeDelete,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    debugPrint('[DB_V2] _onCreate called. Creating all tables for a fresh install...');

    await db.transaction((txn) async {
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS settings (
          id INTEGER PRIMARY KEY, employee_number_prefix TEXT, next_employee_number INTEGER, vehicle_designations TEXT, vendors TEXT, company_hourly_rate REAL, burden_rate REAL, time_rounding_interval INTEGER, auto_backup_reminder_frequency INTEGER, app_runs_since_backup INTEGER, measurement_system TEXT, default_report_months INTEGER, expense_markup_percentage REAL, setup_completed INTEGER DEFAULT 0)
        ''');
      await txn.execute('''
          INSERT INTO settings(id, next_employee_number, company_hourly_rate, burden_rate, time_rounding_interval, auto_backup_reminder_frequency, app_runs_since_backup, default_report_months, expense_markup_percentage, setup_completed)
  VALUES(1, 1, 0.0, 0.0, 15, 10, 0, 3, 0.0, 0)
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS clients (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, contact_person TEXT, phone_number TEXT
          )
        ''');
      // NOTE: Added the new 'project_price' column to the fresh creation schema
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_name TEXT NOT NULL, client_id INTEGER NOT NULL, location TEXT, pricing_model TEXT DEFAULT 'hourly', is_completed INTEGER NOT NULL DEFAULT 0, completion_date TEXT, is_internal INTEGER NOT NULL DEFAULT 0, billed_hourly_rate REAL, project_price REAL, expense_markup_percentage REAL DEFAULT 15.0, FOREIGN KEY (client_id) REFERENCES clients(id), UNIQUE(project_name, client_id)
          )
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, standard_rate REAL NOT NULL DEFAULT 0.0
          )
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_number TEXT UNIQUE, name TEXT NOT NULL, title_id INTEGER, hourly_rate REAL, is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (title_id) REFERENCES roles(id)
          )
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS time_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, employee_id INTEGER, start_time TEXT NOT NULL, end_time TEXT, paused_duration REAL DEFAULT 0.0, final_billed_duration_seconds REAL, hourly_rate REAL, is_paused INTEGER DEFAULT 0, pause_start_time TEXT, is_deleted INTEGER DEFAULT 0, work_details TEXT, phase_id INTEGER, FOREIGN KEY (project_id) REFERENCES projects(id), FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL, FOREIGN KEY (phase_id) REFERENCES phases(id)
          )
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, item_name TEXT NOT NULL, cost REAL NOT NULL, purchase_date TEXT, description TEXT, is_deleted INTEGER DEFAULT 0, expense_category TEXT, unit TEXT, quantity REAL, base_quantity REAL, odometer_reading REAL, is_company_expense INTEGER DEFAULT 0, vehicle_designation TEXT, vendor_or_subtrade TEXT, phase_id INTEGER, FOREIGN KEY (project_id) REFERENCES projects(id), FOREIGN KEY (phase_id) REFERENCES phases(id)
          )
        ''');
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS expense_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL
          )
        ''');
      // NEW: Create phases table for fresh installs
      await txn.execute('''
          CREATE TABLE IF NOT EXISTS phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE
          )
        ''');
    });
    debugPrint('[DB_V2] All tables created and default settings inserted successfully.');
  }

  // =======================================================================
  // |                       DASHBOARD DEDICATED QUERY                     |
  // =======================================================================

  /// Retrieves a specific list of time entries needed for the Dashboard view.
  ///
  /// Criteria:
  /// - Time entries only (based on the time_entries table).
  /// - Entries linked to projects where `is_completed` is NOT 1 (i.e., active).
  /// - Entries that started within the last 7 days.
  /// - Results include project and client names for display (AllRecordViewModel structure).

  // --- START: NEW COST ENTRY DEDICATED QUERY ---

  /// Retrieves material/expense records for the Cost Entry screen.
  ///
  /// @param showCompleted If true, includes materials linked to completed projects.
  /// @param projects The list of project objects to filter against.
  Future<List<JobMaterials>> getCostEntryMaterials(
      bool showCompleted,
      List<Project> allProjects,
      {int? selectedProjectId}
      ) async {
    final db = await database;

    // If a specific project is selected, filter by that project only
    List<int> projectIds;
    if (selectedProjectId != null) {
      projectIds = [selectedProjectId];
    } else {
      // Get project IDs based on filter logic matching the old getProjectRecordsV2
      projectIds = showCompleted
          ? allProjects.where((p) => p.isCompleted && p.id != null).map((p) => p.id!).toList()
          : allProjects.where((p) => (!p.isCompleted || p.isInternal) && p.id != null).map((p) => p.id!).toList();
    }

    if (projectIds.isEmpty) return [];

    final placeholders = projectIds.map((_) => '?').join(',');

    // Get materials/expenses for these projects (similar to old materialsQuery)
    final materialsQuery = await db.query(
      'materials',
      where: 'project_id IN ($placeholders) AND is_deleted = 0',
      whereArgs: projectIds,
      orderBy: 'purchase_date DESC',
      limit: 50, // Keep limit for performance
    );

    // Convert to model objects
    return materialsQuery.map((m) => JobMaterials.fromMap(m)).toList();
  }

// --- END: NEW COST ENTRY DEDICATED QUERY ---

  Future<List<AllRecordViewModel>> getDashboardTimeEntries() async {
    final db = await database;
    final List<AllRecordViewModel> allRecords = [];

    final sevenDaysAgo = DateTime.now().subtract(const Duration(days: 7));
    final sevenDaysAgoIso = sevenDaysAgo.toIso8601String();

    final timeQuery = '''
    SELECT 
      t.id, t.start_time, t.work_details, t.final_billed_duration_seconds, 
      t.employee_id,
      p.project_name, c.name as client_name
    FROM time_entries t
    JOIN projects p ON t.project_id = p.id
    JOIN clients c ON p.client_id = c.id
    WHERE 
      t.is_deleted = 0 
      AND p.is_completed = 0
      AND t.start_time >= ?
    ORDER BY t.start_time DESC
  ''';

    final timeEntryMaps = await db.rawQuery(timeQuery, [sevenDaysAgoIso]);

    for (var map in timeEntryMaps) {
      final projectName = map['project_name'] as String? ?? 'Unknown Project';
      final clientName = map['client_name'] as String? ?? 'Unknown Client';

      allRecords.add(AllRecordViewModel(
        id: map['id'] as int,
        type: RecordType.time,
        date: DateTime.parse(map['start_time'] as String),
        description: map['work_details'] as String? ?? 'No Details',
        value: (map['final_billed_duration_seconds'] as num? ?? 0.0) / 3600.0,
        categoryOrProject: '$clientName - $projectName',
        employeeId: map['employee_id'] as int?,
      ));
    }

    return allRecords;
  }
  // =======================================================================

  Future<List<AllRecordViewModel>> getAllRecordsV2() async {
    final db = await database;
    final List<AllRecordViewModel> allRecords = [];
    final timeQuery = '''
      SELECT t.id, t.start_time, t.work_details, t.final_billed_duration_seconds, p.project_name, c.name as client_name
      FROM time_entries t
      JOIN projects p ON t.project_id = p.id
      JOIN clients c ON p.client_id = c.id
      WHERE t.is_deleted = 0 AND t.start_time IS NOT NULL
    ''';
    final timeEntryMaps = await db.rawQuery(timeQuery);
    for (var map in timeEntryMaps) {
      final projectName = map['project_name'] as String? ?? 'Unknown Project';
      final clientName = map['client_name'] as String? ?? 'Unknown Client';
      allRecords.add(AllRecordViewModel(id: map['id'] as int, type: RecordType.time, date: DateTime.parse(map['start_time'] as String), description: map['work_details'] as String? ?? 'No Details', value: (map['final_billed_duration_seconds'] as num? ?? 0.0) / 3600.0, categoryOrProject: '$clientName - $projectName',));
    }
    final materialQuery = '''
      SELECT m.id, m.purchase_date, m.item_name, m.cost, m.expense_category, p.project_name
      FROM materials m
      JOIN projects p ON m.project_id = p.id
      WHERE m.is_deleted = 0 AND m.purchase_date IS NOT NULL
    ''';
    final materialMaps = await db.rawQuery(materialQuery);
    for (var map in materialMaps) {
      final category = map['expense_category'] as String?;
      final projectName = map['project_name'] as String?;
      String displayCategory = category ?? projectName ?? 'Uncategorized';
      allRecords.add(AllRecordViewModel(id: map['id'] as int, type: RecordType.expense, date: DateTime.parse(map['purchase_date'] as String), description: map['item_name'] as String? ?? 'Unnamed Item', value: (map['cost'] as num? ?? 0.0).toDouble(), categoryOrProject: displayCategory,));
    }
    allRecords.sort((a, b) => b.id.compareTo(a.id));
    return allRecords;
  }

  Future<List<ExpenseCategory>> getExpenseCategoriesV2() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('expense_categories', orderBy: 'name');
    return List.generate(maps.length, (i) => ExpenseCategory.fromMap(maps[i]));
  }

  Future<List<JobMaterials>> getRecentMaterialsV2() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('materials', where: 'is_deleted = 0', orderBy: 'purchase_date DESC', limit: 100,);
    return List.generate(maps.length, (i) => JobMaterials.fromMap(maps[i]));
  }

  Future<List<dynamic>> getProjectRecordsV2(bool showCompleted, List<Project> allProjects) async {
    final db = await database;

    // Get project IDs based on filter
    final projectIds = showCompleted
        ? allProjects.where((p) => p.isCompleted).map((p) => p.id).toList()
        : allProjects.where((p) => !p.isCompleted || p.isInternal).map((p) => p.id).toList();

    if (projectIds.isEmpty) return [];

    final placeholders = projectIds.map((_) => '?').join(',');

    // Get time entries for these projects
    final timeEntriesQuery = await db.query(
      'time_entries',
      where: 'project_id IN ($placeholders) AND is_deleted = 0',
      whereArgs: projectIds,
      orderBy: 'start_time DESC',
      limit: 50,
    );

    // Get materials/expenses for these projects
    final materialsQuery = await db.query(
      'materials',
      where: 'project_id IN ($placeholders) AND is_deleted = 0',
      whereArgs: projectIds,
      orderBy: 'purchase_date DESC',
      limit: 50,
    );

    // Convert to model objects
    final timeEntries = timeEntriesQuery.map((m) => TimeEntry.fromMap(m)).toList();
    final materials = materialsQuery.map((m) => JobMaterials.fromMap(m)).toList();

    // Combine and return both types
    return [...timeEntries, ...materials];
  }

  Future<void> addMaterialV2(JobMaterials expense) async {
    final db = await database;
    await db.insert('materials', expense.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    _notifyListeners();
  }

  Future<void> updateMaterialV2(JobMaterials expense) async {
    final db = await database;
    await db.update('materials', expense.toMap(), where: 'id = ?', whereArgs: [expense.id]);
    _notifyListeners();
  }

  Future<void> addExpenseCategoryV2(ExpenseCategory category) async {
    final db = await database;
    await db.insert('expense_categories', category.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    _notifyListeners();
  }

  Future<void> updateExpenseCategoryV2(ExpenseCategory category) async {
    final db = await database;
    await db.update('expense_categories', category.toMap(), where: 'id = ?', whereArgs: [category.id]);
    _notifyListeners();
  }

  Future<void> deleteRecordV2({required int id, required String fromTable}) async {
    final db = await database;
    if (fromTable == 'time_entries' || fromTable == 'materials') {
      await db.update(fromTable, {'is_deleted': 1}, where: 'id = ?', whereArgs: [id]);
    } else {
      await db.delete(fromTable, where: 'id = ?', whereArgs: [id]);
    }
    _notifyListeners();
  }

  // ============================================================================
  // |                      EXPORT/IMPORT METHODS                             |
  // ============================================================================

  Future<String> exportDatabaseToJson() async {
    debugPrint('[DB_V2] ===== STARTING EXPORT =====');
    final db = await database;
    debugPrint('[DB_V2] Database obtained: ${db.path}');
    debugPrint('[DB_V2] Database isOpen: ${db.isOpen}');

    final Map<String, List<Map<String, dynamic>>> allTables = {};

    const List<String> tableNames = [
      'settings',
      'clients',
      'projects',
      'roles',
      'employees',
      'time_entries',
      'materials',
      'expense_categories',
      'phases' // NEW: Include phases table in export
    ];

    for (String tableName in tableNames) {
      final List<Map<String, dynamic>> tableRows = await db.query(tableName);
      debugPrint('[DB_V2] Table "$tableName" has ${tableRows.length} rows');
      allTables[tableName] = tableRows;
    }

    final Map<String, dynamic> exportData = {
      'export_format_version': 1,
      'export_timestamp_utc': DateTime.now().toUtc().toIso8601String(),
      'database_version': _dbVersion,
      'tables': allTables,
    };

    final jsonString = const JsonEncoder.withIndent('  ').convert(exportData);
    debugPrint('[DB_V2] Export JSON length: ${jsonString.length} characters');
    debugPrint('[DB_V2] ===== EXPORT COMPLETE =====');
    return jsonString;
  }

  Future<void> importDatabaseFromJson(String jsonString) async {
    final db = await database;

    const List<String> deletionOrder = [
      'time_entries',
      'materials',
      'employees',
      'projects',
      'clients',
      'roles',
      'expense_categories',
      'phases', // NEW: Include phases in import/deletion order
      'settings'
    ];

    await db.transaction((txn) async {
      for (String tableName in deletionOrder) {
        await txn.delete(tableName);
      }

      final Map<String, dynamic> jsonData = jsonDecode(jsonString);
      final Map<String, dynamic> tables = jsonData['tables'];

      for (String tableName in tables.keys) {
        final List<dynamic> rows = tables[tableName];
        for (var row in rows) {
          await txn.insert(
            tableName,
            row as Map<String, dynamic>,
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
    });

    _notifyListeners();
    debugPrint('[DB_V2] ===== IMPORT COMPLETE =====');
  }

  // START: ADDED MISSING FUNCTION
  Future<void> deleteAllData() async {
    debugPrint('[DB_V2] ===== DELETING ALL DATA =====');
    final db = await database;

    const List<String> tableNames = [
      'time_entries',
      'materials',
      'employees',
      'projects',
      'clients',
      'roles',
      'expense_categories',
      'phases', // NEW: Include phases in deletion
      'settings'
    ];

    await db.transaction((txn) async {
      for (String tableName in tableNames) {
        await txn.delete(tableName);
      }
    });

    // After deleting, re-create the settings with default values
    await _onCreate(db, _dbVersion);

    _notifyListeners();
    debugPrint('[DB_V2] ===== ALL DATA DELETED =====');
  }
// END: ADDED MISSING FUNCTION
}